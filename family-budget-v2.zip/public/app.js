const categories = {
  expense: ["Їжа","Дім","Авто","Комунальні","Покупки","Розваги","Здоровʼя","Інше"],
  income: ["Зарплата","Премія","Фриланс","Подарунок","Інше"]
};
const members = ["Михайло","Дружина","Спільне"];
const currentMonth = new Date().toISOString().slice(0,7);
const el = id => document.getElementById(id);
const money = n => new Intl.NumberFormat("uk-UA",{style:"currency",currency:"UAH",maximumFractionDigits:0}).format(n);
const dateFmt = s => new Intl.DateTimeFormat("uk-UA",{day:"2-digit",month:"short"}).format(new Date(s+"T00:00:00"));
const escapeHtml = (s="") => s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));

let dashboard = {income:0,expense:0,saved:0,categories:[],recent:[]};
let allTransactions = [];
let budgets = [];

async function api(url, options={}) {
  const res = await fetch(url, {headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  if (!res.ok) {
    let msg = "Помилка сервера";
    try { msg = (await res.json()).error || msg; } catch {}
    throw new Error(msg);
  }
  return res.status === 204 ? null : res.json();
}

async function loadAll(){
  [dashboard, allTransactions, budgets] = await Promise.all([
    api(`/api/dashboard?month=${currentMonth}`),
    api(`/api/transactions`),
    api(`/api/budgets`)
  ]);
  render();
}

function render(){
  renderSummary();
  renderBudgetOverview();
  renderCategoryOverview();
  renderRecent();
  renderTransactions();
  renderBudgetCards();
  renderAnalytics();
  populateFilters();
}

function renderSummary(){
  const income=dashboard.income, expense=dashboard.expense, saved=dashboard.saved;
  el("summaryGrid").innerHTML=[
    card("Дохід",money(income),"Поточний місяць","positive"),
    card("Витрати",money(expense),"Поточний місяць","negative"),
    card("Заощадження",money(saved),saved>=0?"Доходи мінус витрати":"Перевищення витрат",saved>=0?"positive":"negative"),
    card("Частка заощаджень",income?`${Math.round(saved/income*100)}%`:"0%","Від поточного доходу",saved>=0?"positive":"negative")
  ].join("");
  el("monthLabel").textContent=new Intl.DateTimeFormat("uk-UA",{month:"long",year:"numeric"}).format(new Date());
}
function card(label,value,sub,cls=""){
  return `<div class="summary-card"><div class="summary-label">${label}</div><div class="summary-value ${cls}">${value}</div><div class="summary-sub">${sub}</div></div>`;
}
function renderBudgetOverview(){
  const spentMap=Object.fromEntries(dashboard.categories.map(x=>[x.category,x.amount]));
  el("budgetOverview").innerHTML=budgets.map(b=>{
    const spent=spentMap[b.category]||0, pct=Math.min(100,b.amount?spent/b.amount*100:0);
    return `<div class="category-row"><div class="category-main"><span class="dot"></span><div><strong>${escapeHtml(b.category)}</strong><div class="muted">${money(spent)} / ${money(b.amount)}</div></div></div><div class="category-bar"><span style="width:${pct}%"></span></div><div class="tx-meta">${Math.round(pct)}%</div></div>`;
  }).join("") || `<div class="empty">Ще немає бюджетів.</div>`;
}
function renderCategoryOverview(){
  const entries=dashboard.categories, total=entries.reduce((a,x)=>a+x.amount,0);
  el("categoryOverview").innerHTML=entries.length ? entries.slice(0,6).map(x=>{
    const pct=total?Math.round(x.amount/total*100):0;
    return `<div class="category-row"><div class="category-main"><span class="dot"></span><strong>${escapeHtml(x.category)}</strong></div><div class="category-bar"><span style="width:${pct}%"></span></div><strong>${money(x.amount)}</strong></div>`;
  }).join(""):`<div class="empty">Додай перші витрати — тут зʼявиться аналітика.</div>`;
}
function txRow(t){
  return `<div class="transaction"><div class="tx-main"><strong>${escapeHtml(t.title)}</strong><span>${escapeHtml(t.category)} · ${escapeHtml(t.member)}</span></div><div class="tx-meta">${dateFmt(t.date)}</div><div class="tx-meta">${escapeHtml(t.note||"—")}</div><div class="tx-amount ${t.type==="income"?"tx-income":"tx-expense"}">${t.type==="income"?"+":"−"} ${money(t.amount)}</div><button class="icon-btn delete-tx" data-id="${t.id}" aria-label="Видалити">×</button></div>`;
}
function renderRecent(){ el("recentTransactions").innerHTML=dashboard.recent.length?dashboard.recent.map(txRow).join(""):`<div class="empty">Операцій ще немає.</div>`; }

function renderTransactions(){
  const type=el("transactionTypeFilter").value, cat=el("transactionCategoryFilter").value, q=el("transactionSearch").value.trim().toLowerCase();
  let list=[...allTransactions];
  if(type!=="all") list=list.filter(t=>t.type===type);
  if(cat!=="all") list=list.filter(t=>t.category===cat);
  if(q) list=list.filter(t=>`${t.title} ${t.note} ${t.member} ${t.category}`.toLowerCase().includes(q));
  el("transactionsTable").innerHTML=list.length?list.map(txRow).join(""):`<div class="empty">Нічого не знайдено.</div>`;
}
function renderBudgetCards(){
  const spentMap=Object.fromEntries(dashboard.categories.map(x=>[x.category,x.amount]));
  el("budgetCards").innerHTML=budgets.map(b=>{
    const spent=spentMap[b.category]||0, remaining=b.amount-spent, pct=Math.min(100,b.amount?spent/b.amount*100:0);
    return `<article class="card budget-card"><div class="budget-title"><div><h2>${escapeHtml(b.category)}</h2><div class="muted">Місячний ліміт</div></div><strong class="${remaining<0?"negative":"positive"}">${money(remaining)}</strong></div><div class="progress"><span style="width:${pct}%"></span></div><div class="progress-row"><span>${money(spent)} витрачено</span><span>${money(b.amount)}</span></div></article>`;
  }).join("");
}
function renderAnalytics(){
  const byMonth=new Map();
  allTransactions.forEach(t=>{
    const m=t.date.slice(0,7);
    if(!byMonth.has(m)) byMonth.set(m,{income:0,expense:0});
    byMonth.get(m)[t.type]+=Number(t.amount);
  });
  const months=[]; const start=new Date(); start.setMonth(start.getMonth()-5); start.setDate(1);
  for(let i=0;i<6;i++){const d=new Date(start.getFullYear(),start.getMonth()+i,1);months.push({key:d.toISOString().slice(0,7),label:new Intl.DateTimeFormat("uk-UA",{month:"short"}).format(d)});}
  const vals=months.map(m=>({...m,...(byMonth.get(m.key)||{income:0,expense:0})}));
  const max=Math.max(1,...vals.flatMap(v=>[v.income,v.expense]));
  el("monthlyChart").innerHTML=vals.map(v=>`<div class="bar-col"><div class="bar-pair"><div class="bar income" style="height:${v.income/max*100}%"></div><div class="bar expense" style="height:${v.expense/max*100}%"></div></div><div class="bar-label">${v.label}</div></div>`).join("")+`<div class="legend"><span><i style="background:var(--green)"></i>Доходи</span><span><i style="background:var(--red)"></i>Витрати</span></div>`;
  const total=dashboard.categories.reduce((a,x)=>a+x.amount,0);
  el("categoryChart").innerHTML=dashboard.categories.map(x=>{
    const pct=total?Math.round(x.amount/total*100):0;
    return `<div class="category-row"><div class="category-main"><span class="dot"></span><strong>${escapeHtml(x.category)}</strong></div><div class="category-bar"><span style="width:${pct}%"></span></div><strong>${pct}%</strong></div>`;
  }).join("")||`<div class="empty">Немає витрат для аналізу.</div>`;
}
function populateFilters(){
  const cats=[...new Set(allTransactions.map(t=>t.category))].sort(), select=el("transactionCategoryFilter"), current=select.value;
  select.innerHTML=`<option value="all">Всі категорії</option>`+cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("");
  select.value=cats.includes(current)?current:"all";
}
function fillCategoryOptions(type){el("txCategory").innerHTML=categories[type].map(c=>`<option>${c}</option>`).join("");}
function openModal(){el("modalBackdrop").hidden=false;el("txDate").value=new Date().toISOString().slice(0,10);fillCategoryOptions("expense");el("txMember").innerHTML=members.map(m=>`<option>${m}</option>`).join("");el("txTitle").focus();}
function closeModal(){el("modalBackdrop").hidden=true;}
function switchView(view){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  el("view-"+view).classList.add("active");
  document.querySelectorAll(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  const names={dashboard:"Головна",transactions:"Операції",budgets:"Бюджети",analytics:"Аналітика",data:"Дані",settings:"Налаштування"};
  el("pageTitle").textContent=names[view]||"Головна"; el("sidebar").classList.remove("open");
}
async function addTransaction(e){
  e.preventDefault();
  try{
    const type=document.querySelector('input[name="type"]:checked').value;
    await api("/api/transactions",{method:"POST",body:JSON.stringify({
      date:el("txDate").value,type,amount:Number(el("txAmount").value),
      category:el("txCategory").value,member:el("txMember").value,
      title:el("txTitle").value.trim(),note:el("txNote").value.trim()
    })});
    closeModal(); el("transactionForm").reset(); await loadAll();
  }catch(err){alert(err.message);}
}
async function deleteTransaction(id){
  try{await api(`/api/transactions/${id}`,{method:"DELETE"});await loadAll();}catch(err){alert(err.message);}
}
async function exportData(){
  const data=await api("/api/export"), blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`family-budget-${currentMonth}.json`;a.click();URL.revokeObjectURL(a.href);
}
async function importData(file){
  try{const data=JSON.parse(await file.text());await api("/api/import",{method:"POST",body:JSON.stringify(data)});await loadAll();alert("Дані імпортовано.");}
  catch(err){alert(err.message);}
}
document.addEventListener("click",async e=>{
  const nav=e.target.closest("[data-view]"); if(nav) switchView(nav.dataset.view);
  const target=e.target.closest("[data-view-target]"); if(target) switchView(target.dataset.viewTarget);
  const del=e.target.closest(".delete-tx"); if(del&&confirm("Видалити цю операцію?")) await deleteTransaction(del.dataset.id);
});
el("addTransactionBtn").addEventListener("click",openModal);
el("closeModal").addEventListener("click",closeModal);
el("modalBackdrop").addEventListener("click",e=>{if(e.target===el("modalBackdrop"))closeModal();});
el("transactionForm").addEventListener("submit",addTransaction);
document.querySelectorAll('input[name="type"]').forEach(r=>r.addEventListener("change",()=>fillCategoryOptions(r.value)));
el("transactionTypeFilter").addEventListener("change",renderTransactions);
el("transactionCategoryFilter").addEventListener("change",renderTransactions);
el("transactionSearch").addEventListener("input",renderTransactions);
el("exportBtn").addEventListener("click",()=>exportData().catch(err=>alert(err.message)));
el("importInput").addEventListener("change",e=>e.target.files[0]&&importData(e.target.files[0]));
el("menuBtn").addEventListener("click",()=>el("sidebar").classList.toggle("open"));

loadAll().catch(err=>{console.error(err);alert("Не вдалося підключитися до сервера.");});
