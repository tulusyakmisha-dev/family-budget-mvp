# Family Budget v2

Це наступний етап Family Budget: фронтенд тепер працює через API, а дані зберігаються у SQLite.

## Стек

- Node.js
- Express
- SQLite (`better-sqlite3`)
- HTML/CSS/JavaScript

## Запуск

Потрібен Node.js 20+.

```bash
npm install
npm start
```

Потім відкрий:

http://localhost:3000

База `family-budget.db` створюється автоматично.

## API

- `GET /api/health`
- `GET /api/dashboard?month=YYYY-MM`
- `GET /api/transactions`
- `POST /api/transactions`
- `DELETE /api/transactions/:id`
- `GET /api/budgets`
- `PUT /api/budgets/:category`
- `GET /api/export`
- `POST /api/import`

## Що змінилося

У v1 дані жили лише у LocalStorage браузера. У v2:
- дані централізовані у БД;
- інтерфейс спілкується із сервером через API;
- є серверний import/export;
- фундамент готовий для авторизації та синхронізації.

## Наступний етап

1. Користувачі та авторизація
2. Сім'ї + учасники
3. Спільні рахунки
4. PostgreSQL для production
5. Ролі та права доступу
6. Open Banking / банківські інтеграції
7. SwiftUI-клієнт
