import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Database from "better-sqlite3";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;

const db = new Database(path.join(__dirname, "family-budget.db"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('income','expense')),
    amount REAL NOT NULL CHECK(amount > 0),
    category TEXT NOT NULL,
    member TEXT NOT NULL,
    title TEXT NOT NULL,
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL UNIQUE,
    amount REAL NOT NULL CHECK(amount >= 0)
  );
`);

const count = db.prepare("SELECT COUNT(*) AS count FROM budgets").get().count;
if (count === 0) {
  const insert = db.prepare("INSERT INTO budgets (category, amount) VALUES (?, ?)");
  const defaults = [
    ["Їжа", 12000], ["Дім", 9000], ["Авто", 10000],
    ["Комунальні", 7000], ["Покупки", 7000], ["Розваги", 4500],
    ["Здоровʼя", 3000], ["Інше", 5000]
  ];
  const seed = db.transaction(() => defaults.forEach(([c, a]) => insert.run(c, a)));
  seed();
}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function validateTransaction(body) {
  if (!body) return "Немає даних";
  if (!["income", "expense"].includes(body.type)) return "Некоректний тип операції";
  if (!body.date || !/^\d{4}-\d{2}-\d{2}$/.test(body.date)) return "Некоректна дата";
  if (!Number.isFinite(Number(body.amount)) || Number(body.amount) <= 0) return "Некоректна сума";
  if (!body.category || !body.member || !body.title) return "Заповни обов'язкові поля";
  return null;
}

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.get("/api/transactions", (req, res) => {
  const month = String(req.query.month || "");
  const type = String(req.query.type || "");
  const category = String(req.query.category || "");
  const q = String(req.query.q || "").trim().toLowerCase();

  let sql = "SELECT * FROM transactions";
  const where = [];
  const params = [];

  if (/^\d{4}-\d{2}$/.test(month)) {
    where.push("substr(date, 1, 7) = ?");
    params.push(month);
  }
  if (["income", "expense"].includes(type)) {
    where.push("type = ?");
    params.push(type);
  }
  if (category) {
    where.push("category = ?");
    params.push(category);
  }
  if (q) {
    where.push("(lower(title) LIKE ? OR lower(note) LIKE ? OR lower(member) LIKE ? OR lower(category) LIKE ?)");
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  if (where.length) sql += " WHERE " + where.join(" AND ");
  sql += " ORDER BY date DESC, id DESC";

  res.json(db.prepare(sql).all(...params));
});

app.post("/api/transactions", (req, res) => {
  const error = validateTransaction(req.body);
  if (error) return res.status(400).json({ error });

  const stmt = db.prepare(`
    INSERT INTO transactions (date, type, amount, category, member, title, note)
    VALUES (@date, @type, @amount, @category, @member, @title, @note)
  `);

  const result = stmt.run({
    date: req.body.date,
    type: req.body.type,
    amount: Number(req.body.amount),
    category: String(req.body.category),
    member: String(req.body.member),
    title: String(req.body.title).trim(),
    note: String(req.body.note || "").trim()
  });

  res.status(201).json(
    db.prepare("SELECT * FROM transactions WHERE id = ?").get(result.lastInsertRowid)
  );
});

app.delete("/api/transactions/:id", (req, res) => {
  const result = db.prepare("DELETE FROM transactions WHERE id = ?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Операцію не знайдено" });
  res.status(204).end();
});

app.get("/api/budgets", (_req, res) => {
  res.json(db.prepare("SELECT * FROM budgets ORDER BY category").all());
});

app.put("/api/budgets/:category", (req, res) => {
  const amount = Number(req.body.amount);
  if (!Number.isFinite(amount) || amount < 0) {
    return res.status(400).json({ error: "Некоректний бюджет" });
  }
  db.prepare(`
    INSERT INTO budgets (category, amount) VALUES (?, ?)
    ON CONFLICT(category) DO UPDATE SET amount=excluded.amount
  `).run(req.params.category, amount);

  res.json(db.prepare("SELECT * FROM budgets WHERE category = ?").get(req.params.category));
});

app.get("/api/dashboard", (req, res) => {
  const month = String(req.query.month || new Date().toISOString().slice(0, 7));
  const totals = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN type='income' THEN amount ELSE 0 END), 0) AS income,
      COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END), 0) AS expense
    FROM transactions
    WHERE substr(date,1,7)=?
  `).get(month);

  const categories = db.prepare(`
    SELECT category, SUM(amount) AS amount
    FROM transactions
    WHERE substr(date,1,7)=? AND type='expense'
    GROUP BY category
    ORDER BY amount DESC
  `).all(month);

  const recent = db.prepare(`
    SELECT * FROM transactions
    ORDER BY date DESC, id DESC
    LIMIT 8
  `).all();

  res.json({
    month,
    income: totals.income,
    expense: totals.expense,
    saved: totals.income - totals.expense,
    categories,
    recent
  });
});

app.get("/api/export", (_req, res) => {
  const payload = {
    version: 2,
    exportedAt: new Date().toISOString(),
    transactions: db.prepare("SELECT * FROM transactions ORDER BY date DESC, id DESC").all(),
    budgets: db.prepare("SELECT category, amount FROM budgets ORDER BY category").all()
  };
  res.json(payload);
});

app.post("/api/import", (req, res) => {
  const payload = req.body;
  if (!payload || !Array.isArray(payload.transactions) || !Array.isArray(payload.budgets)) {
    return res.status(400).json({ error: "Невірний формат резервної копії" });
  }

  const insertTx = db.prepare(`
    INSERT INTO transactions (date, type, amount, category, member, title, note)
    VALUES (@date, @type, @amount, @category, @member, @title, @note)
  `);
  const upsertBudget = db.prepare(`
    INSERT INTO budgets (category, amount) VALUES (?, ?)
    ON CONFLICT(category) DO UPDATE SET amount=excluded.amount
  `);

  const importAll = db.transaction(() => {
    for (const t of payload.transactions) {
      const error = validateTransaction(t);
      if (!error) {
        insertTx.run({
          date: t.date,
          type: t.type,
          amount: Number(t.amount),
          category: String(t.category),
          member: String(t.member),
          title: String(t.title),
          note: String(t.note || "")
        });
      }
    }
    for (const b of payload.budgets) {
      if (b.category && Number.isFinite(Number(b.amount)) && Number(b.amount) >= 0) {
        upsertBudget.run(String(b.category), Number(b.amount));
      }
    }
  });

  importAll();
  res.json({ ok: true });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Family Budget running at http://localhost:${PORT}`);
});
